package com.baizhi.Test;


import com.baizhi.Dao.UserDao;
import com.baizhi.Dao.impl.UserDaoImpl;
import com.baizhi.entity.User;

import org.junit.Test;

public class UserDaoTest extends UserDaoImpl {
    UserDao userDao = new UserDaoImpl();

    @Test
    public void selectByNameAndPassword() {
        User user = userDao.selectByNameAndPassword("ydd", "123456");
        if (user != null) {
            System.out.println("登录成功");
        } else {
            System.out.println("登录失败");
            //return null;
        }
    }

    @Test
    public void TestinsertUser() {
       int i= userDao.insertUser(new User(null,"yddd","123456"));
        if (i>0) {
            System.out.println("注册成功");
        } else {
            System.out.println("注册失败");
        }
    }
}
