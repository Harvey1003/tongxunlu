package com.baizhi.Test;

import com.baizhi.Dao.PersonDao;
import com.baizhi.Dao.impl.PersonDaoImpl;
import com.baizhi.entity.Person;
import org.junit.Test;

import java.util.List;

public class PersonDaoTest {
    PersonDao personDao = new PersonDaoImpl();
    @Test
    public void TestselectAll(){
        List<Person> list = personDao.selectAll();
        for (Person person:list){
            System.out.println(person.getPersonName());
        }

    }
    @Test
    public void testAdd(){
        boolean b = personDao.addPerson(new Person(null, "羊蛋", 22, "男", "159123123", "JP"));
        System.out.println(b);
    }
    @Test
    public void testfindPerson(){
        Person person = personDao.findPerson(1);
        System.out.println(person.getPersonName());
    }
    @Test
    public void testupdate(){
        Person person = new Person(12, "羊蛋", 22, "男", "159123123", "JP");
        personDao.updataPerson(person);
    }
}
