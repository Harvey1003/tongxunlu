package com.baizhi.Test;

import com.baizhi.service.UserService;
import com.baizhi.service.impl.UserServiceImpl;
import org.junit.Test;

public class UserServiceTest {
  UserService userService=  new UserServiceImpl();
  @Test
    public void testRegi(){
    boolean b = userService.register("admin", "123456", "123456");
    System.out.println(b);
  }
}
