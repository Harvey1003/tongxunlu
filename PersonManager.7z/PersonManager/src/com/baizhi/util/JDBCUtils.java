package com.baizhi.util;

import java.io.InputStream;
import java.sql.*;
import java.util.Properties;

public class JDBCUtils {
	private static ThreadLocal<Connection> tl = new ThreadLocal<Connection>();
	private static Properties prop = new Properties();
	static {
		try {
			//通过流读取jdbc.properties文件中内容
			//通过类对象的getResourceAsStream()获取配置文件输入流
//			InputStream in = new FileInputStream("./src/jdbc.properties");
			// /表示com超级父包所在的目录 
			InputStream in = JDBCUtils.class.getResourceAsStream("/jdbc.properties");
			//自动的使用输入流读取配置文件，并将键值对数据保存到本身
			prop.load(in);
			in.close();
			String driverClassName = prop.getProperty("driverClassName");
			Class.forName(driverClassName);
			//System.out.println("driverClassName="+driverClassName);
		}catch(Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}
	
	//抽取JDBC前2步
	public static Connection getConnection() {
		
		//从当前线程空间中获取conn
		Connection  conn = tl.get();
		
		//如果获取不到，说明是第1次获取连接，则从数据库中获取，然后保存到线程中
		if(conn == null) {
			try {
				
				String url = prop.getProperty("url");
				String user = prop.getProperty("user");
				String password = prop.getProperty("password");
				//System.out.println("url="+url);
				//System.out.println("user="+user);
				//System.out.println("password="+password);
				
				conn = DriverManager.getConnection(url, user, password);
				tl.set(conn);
			}catch(Exception e) {
				e.printStackTrace();
				throw new RuntimeException(e);
			}
		}
        //conn不为空，说明不是第1次，则直接返回从线程对象中获取的连接
		return conn;
	}
	//抽取JDBC最后1步
	public static void close(Connection conn,PreparedStatement pstm,ResultSet rs) {
		if(rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(pstm != null) {
			try {
				pstm.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(conn != null) {
			try {
				conn.close();
                //连接关闭后，要从线程对象中移除连接
				tl.remove();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
}