package com.baizhi.service.impl;

import com.baizhi.Dao.UserDao;
import com.baizhi.Dao.impl.UserDaoImpl;
import com.baizhi.entity.User;
import com.baizhi.service.UserService;

public class UserServiceImpl implements UserService {
    UserDao userDao = new UserDaoImpl();

    @Override
    public boolean Login(String username, String password) {
        User user = userDao.selectByNameAndPassword(username, password);
        if (user != null) {
            System.out.println("登录成功");
            return true;
        } else {
            System.out.println("登录失败");
            return false;
        }

    }

    //注册
    @Override
    public boolean register(String username, String password, String password1) {
        if (password.equals(password1)) {
            User user = new User(null,username, password);
            int i = userDao.insertUser(user);
            if (i > 0) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }


}
