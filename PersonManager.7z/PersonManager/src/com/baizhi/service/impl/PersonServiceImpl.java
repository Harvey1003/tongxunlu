package com.baizhi.service.impl;

import com.baizhi.Dao.PersonDao;
import com.baizhi.Dao.impl.PersonDaoImpl;
import com.baizhi.entity.Person;
import com.baizhi.service.PersonService;

import java.util.List;

public class PersonServiceImpl implements PersonService {
    PersonDao personDao = new PersonDaoImpl();

    @Override
    public List<Person> selectAll() {
        List<Person> list = personDao.selectAll();
        return list;
    }

    @Override
    public boolean addPerson(Person person) {
        boolean b = personDao.addPerson(person);
        return b;
    }

    @Override
    public boolean updataPerson(Person person) {
        int i = personDao.updataPerson(person);
        if (i > 0) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean deletPerson(Integer id) {
        return false;
    }

    @Override
    public Person findPerson(Integer id) {
        Person person = personDao.findPerson(id);
        return person;
    }
}
