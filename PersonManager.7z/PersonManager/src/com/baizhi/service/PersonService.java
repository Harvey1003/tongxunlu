package com.baizhi.service;

import com.baizhi.entity.Person;

import java.util.List;

public interface PersonService {
    List<Person> selectAll();
    boolean addPerson(Person person);
    boolean updataPerson(Person person);
    boolean deletPerson(Integer id);
    Person findPerson(Integer id);
}
