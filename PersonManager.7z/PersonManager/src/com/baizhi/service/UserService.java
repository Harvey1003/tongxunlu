package com.baizhi.service;

import com.baizhi.entity.User;

public interface UserService {
    boolean Login(String username,String password);
    boolean register(String username,String password,String password1);

}
