package com.baizhi.Dao;

import com.baizhi.entity.User;

public interface UserDao {
    User selectByNameAndPassword(String username,String password);
    int insertUser(User user);

}
