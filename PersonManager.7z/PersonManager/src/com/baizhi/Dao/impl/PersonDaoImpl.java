package com.baizhi.Dao.impl;

import com.baizhi.Dao.PersonDao;
import com.baizhi.entity.Person;
import com.baizhi.util.JDBCUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class PersonDaoImpl implements PersonDao {
    Connection conn = null;
    PreparedStatement pstm = null;
    ResultSet rs = null;

    @Override
    public List<Person> selectAll() {

        try {
            conn = JDBCUtils.getConnection();
            pstm = conn.prepareStatement("select * from t_person");
            rs = pstm.executeQuery();
            List<Person> list = new ArrayList<>();
            Person person = null;
            while (rs.next()) {
                int person_id = rs.getInt("person_id");
                String personname = rs.getString("person_name");
                int age = rs.getInt("age");
                String sex = rs.getString("sex");
                String mobile = rs.getString("mobile");
                String address = rs.getString("address");
                person = new Person(person_id, personname, age, sex, mobile, address);
                list.add(person);
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            JDBCUtils.close(conn, pstm, rs);
        }
    }

    @Override
    public boolean addPerson(Person person) {
        try {
            conn = JDBCUtils.getConnection();
            pstm = conn.prepareStatement("INSERT INTO t_person VALUES (null,?, ?,?,?,?)");
            pstm.setString(1, person.getPersonName());
            pstm.setInt(2, person.getAge());
            pstm.setString(3, person.getSex());
            pstm.setString(4, person.getMobile());
            pstm.setString(5, person.getAddress());
            int i = pstm.executeUpdate();
            if (i > 0) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            JDBCUtils.close(conn, pstm, null);
        }
    }

    @Override
    public int updataPerson(Person person) {
        try {
            conn = JDBCUtils.getConnection();
            pstm = conn.prepareStatement("UPDATE t_person SET person_name = ?, age = ?, sex = ?, mobile = ?, address = ? WHERE person_id = ?");
            pstm.setString(1, person.getPersonName());
            pstm.setInt(2, person.getAge());
            pstm.setString(3, person.getSex());
            pstm.setString(4, person.getMobile());
            pstm.setString(5, person.getAddress());
            pstm.setInt(6,person.getPersonId());
            int i = pstm.executeUpdate();
            return i;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        } finally {
            JDBCUtils.close(conn, pstm, rs);
        }

    }

    @Override
    public boolean deletPerson(Integer id) {
        try {
            conn = JDBCUtils.getConnection();
            pstm = conn.prepareStatement("DELETE FROM t_person WHERE person_id = ?");
            pstm.setInt(1, id);
            int i = pstm.executeUpdate();
            if (i > 0) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            JDBCUtils.close(conn, pstm, null);
        }
    }

    @Override
    public Person findPerson(Integer id) {
        try {
            conn = JDBCUtils.getConnection();
            pstm = conn.prepareStatement("select * from t_person where person_id=?");
            pstm.setInt(1, id);
            rs = pstm.executeQuery();
            Person person = null;
            while (rs.next()) {
                int person_id = rs.getInt("person_id");
                String personname = rs.getString("person_name");
                int age = rs.getInt("age");
                String sex = rs.getString("sex");
                String mobile = rs.getString("mobile");
                String address = rs.getString("address");
                person = new Person(person_id, personname, age, sex, mobile, address);
            }
            return person;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            JDBCUtils.close(conn, pstm, rs);
        }
    }
}
