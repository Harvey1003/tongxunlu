package com.baizhi.Dao.impl;

import com.baizhi.Dao.UserDao;
import com.baizhi.entity.User;
import com.baizhi.util.JDBCUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserDaoImpl implements UserDao {
    Connection conn=null;
    PreparedStatement pstm= null;
    ResultSet rs=null;
    @Override
    public User selectByNameAndPassword(String username, String password) {
        try {
            conn=JDBCUtils.getConnection();
             pstm = conn.prepareStatement("select * from t_user where username=? and password=?");
             pstm.setString(1,username);
             pstm.setString(2,password);
            rs = pstm.executeQuery();
            User user=null;
            while (rs.next()){
                user=new User(rs.getInt("user_id"),rs.getString("username"), rs.getString("password"));
            }
            return user;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }finally {
            JDBCUtils.close(conn,pstm,rs);
        }
    }

    @Override
    public int insertUser(User user) {
        try {
            conn=JDBCUtils.getConnection();
            pstm = conn.prepareStatement("insert into t_user values (null ,?,?)");
            pstm.setString(1,user.getUsername());
            pstm.setString(2,user.getPassword());
            int i = pstm.executeUpdate();
            return i;
        }catch (Exception e){
            e.printStackTrace();
            return 0;
        }finally {
            JDBCUtils.close(conn,pstm,null);
        }


    }
}
