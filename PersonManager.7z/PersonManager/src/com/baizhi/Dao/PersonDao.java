package com.baizhi.Dao;

import com.baizhi.entity.Person;

import java.util.List;

public interface PersonDao {
     List<Person> selectAll();
     boolean addPerson(Person person);
     int updataPerson(Person person);
     boolean deletPerson(Integer id);
     Person findPerson(Integer id);
}
