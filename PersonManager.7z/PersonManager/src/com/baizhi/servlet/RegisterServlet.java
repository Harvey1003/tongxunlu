package com.baizhi.servlet;

import com.baizhi.service.UserService;
import com.baizhi.service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        String username = req.getParameter("username");
        String password1 = req.getParameter("password1");
        String password2 = req.getParameter("password2");
        System.out.println(username);
        System.out.println(password1);
        System.out.println(password2);
        UserService userService = new UserServiceImpl();
        boolean b = userService.register(username, password1, password2);
        System.out.println();
        if (b){
            resp.sendRedirect("/PersonManager/login.jsp");
        }else {
           resp.sendRedirect("/PersonManager/register.jsp");
        }
    }
}
