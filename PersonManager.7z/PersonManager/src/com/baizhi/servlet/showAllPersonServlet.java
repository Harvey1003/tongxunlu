package com.baizhi.servlet;

import com.baizhi.entity.Person;
import com.baizhi.service.PersonService;
import com.baizhi.service.impl.PersonServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/showAllPerson")
public class showAllPersonServlet extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PersonService personService=new PersonServiceImpl();
        List<Person> list = personService.selectAll();
        req.setAttribute("personList",list);
        req.getRequestDispatcher("/showAllPerson.jsp").forward(req,resp);
    }
}
