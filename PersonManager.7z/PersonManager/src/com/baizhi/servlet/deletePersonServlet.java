package com.baizhi.servlet;

import com.baizhi.Dao.PersonDao;
import com.baizhi.Dao.impl.PersonDaoImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/deletePerson")
public class deletePersonServlet extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        String id1 = req.getParameter("personId");
        int id = Integer.parseInt(id1);
        PersonDao personDao = new PersonDaoImpl();
        personDao.deletPerson(id);
        resp.sendRedirect("/PersonManager/showAllPerson");


    }
}
