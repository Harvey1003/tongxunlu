package com.baizhi.servlet;

import com.baizhi.Dao.PersonDao;
import com.baizhi.Dao.impl.PersonDaoImpl;
import com.baizhi.entity.Person;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
@WebServlet("/addPerson")
public class AddPersonServlet extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //
        req.setCharacterEncoding("utf-8");
        String username = req.getParameter("personName");
        String agestr = req.getParameter("age");
        String sex = req.getParameter("sex");
        String mobile = req.getParameter("mobile");
        String address = req.getParameter("address");
        //
        int age = Integer.parseInt(agestr);
        Person person = new Person(null, username, age, sex, mobile, address);
        PersonDao personDao = new PersonDaoImpl();
        boolean b = personDao.addPerson(person);
        if(b){
            resp.sendRedirect("/PersonManager/showAllPerson");
        }else {
            resp.sendRedirect("/PersonManager/addPerson.jsp");

        }
    }
}
