package com.baizhi.servlet;

import com.baizhi.Dao.PersonDao;
import com.baizhi.Dao.impl.PersonDaoImpl;
import com.baizhi.entity.Person;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
@WebServlet("/findPerson")
public class findPersonServlet extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        String idstr = req.getParameter("personId");
        int id = Integer.parseInt(idstr);
        PersonDao personDao=new PersonDaoImpl();
        Person person = personDao.findPerson(id);
        req.setAttribute("person",person);
        req.getRequestDispatcher("/updatePerson.jsp").forward(req,resp);

    }
}
