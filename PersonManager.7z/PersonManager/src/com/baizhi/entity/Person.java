package com.baizhi.entity;

import java.io.Serializable;

public class Person implements Serializable {
    private Integer personId;
    private String personName;
    private Integer age;
    private String sex;
    private String mobile;
    private String address;

    public Person() {
    }

    public Person(Integer personId, String personName, Integer age, String sex, String mobile, String address) {
        this.personId = personId;
        this.personName = personName;
        this.age = age;
        this.sex = sex;
        this.mobile = mobile;
        this.address = address;
    }

    public Integer getPersonId() {
        return personId;
    }

    public void setPersonId(Integer personId) {
        this.personId = personId;
    }

    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
